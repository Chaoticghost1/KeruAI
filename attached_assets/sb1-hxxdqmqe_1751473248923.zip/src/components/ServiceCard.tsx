import React from 'react';
import { ArrowRight, Users, Clock, CheckCircle } from 'lucide-react';
import { ServiceCard as ServiceCardType } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

interface ServiceCardProps {
  service: ServiceCardType;
  onClick?: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onClick }) => {
  const { language } = useLanguage();
  const { user } = useAuth();
  
  const content = service.content[language];
  
  // Get user progress for this service
  const userCheckpoints = user?.checkpoints.filter(cp => cp.service === service.id) || [];
  const userQualifications = user?.qualifications.filter(q => q.service === service.id) || [];

  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 overflow-hidden">
      {/* Progress indicator if user has progress */}
      {userCheckpoints.length > 0 && (
        <div className="bg-gradient-to-r from-green-500 to-emerald-500 px-4 py-2">
          <div className="flex items-center space-x-2 text-white text-sm">
            <CheckCircle className="w-4 h-4" />
            <span>{userCheckpoints.length} checkpoints completados</span>
          </div>
        </div>
      )}

      <div className="p-6">
        {/* Service Title */}
        <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
          {content.title}
        </h3>

        {/* Service Description */}
        <p className="text-gray-600 mb-4 leading-relaxed">
          {content.description}
        </p>

        {/* Stats Row */}
        <div className="flex items-center space-x-4 mb-4 text-sm text-gray-500">
          <div className="flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{Math.floor(Math.random() * 500 + 100)}+ usuarios</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{Math.floor(Math.random() * 30 + 10)} min</span>
          </div>
        </div>

        {/* User Qualifications */}
        {userQualifications.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-2">
              {userQualifications.map((qual, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium"
                >
                  Nivel {qual.level}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* CTA Button */}
        {content.cta && (
          <button
            onClick={onClick}
            className="group/btn flex items-center justify-between w-full px-4 py-3 bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 text-blue-600 rounded-lg font-medium transition-all"
          >
            <span>{content.cta}</span>
            <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
          </button>
        )}
      </div>

      {/* Hover effect overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
    </div>
  );
};

export default ServiceCard;