import React from 'react';
import { Heart, Twitter, Youtube, Github } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  const socialLinks = [
    { icon: Twitter, url: 'https://twitter.com/electrobitai', label: 'Twitter' },
    { icon: Youtube, url: 'https://youtube.com/@electrobitai', label: 'YouTube' },
    { icon: Github, url: 'https://github.com/electrobitai', label: 'GitHub' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">E</span>
              </div>
              <span className="font-bold text-xl">Electrobit.ai Suite</span>
            </div>
            <p className="text-gray-400 mb-4 max-w-md">
              Tecnología, educación y oportunidades para Honduras y el mundo. 
              Construyendo el futuro con herramientas de IA accesibles para todos.
            </p>
            <div className="flex items-center space-x-2 text-gray-400">
              <span>Construido con</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>desde Honduras por Kevin Guillen</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Servicios</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#studybuddy" className="hover:text-white transition-colors">Aprende Conmigo IA</a></li>
              <li><a href="#budgetpal" className="hover:text-white transition-colors">BudgetPal</a></li>
              <li><a href="#cruiseword" className="hover:text-white transition-colors">CruiseWord Game</a></li>
              <li><a href="#aethosbyte" className="hover:text-white transition-colors">AethosByte</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Contacto</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Email: hola@electrobit.ai</li>
              <li>Honduras, Centroamérica</li>
              <li>
                <div className="flex items-center space-x-3 mt-4">
                  {socialLinks.map((social, index) => (
                    <a
                      key={index}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                      aria-label={social.label}
                    >
                      <social.icon className="w-4 h-4" />
                    </a>
                  ))}
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
          <div className="text-gray-400 text-sm">
            © 2024 Electrobit.ai Suite. Todos los derechos reservados.
          </div>
          <div className="flex items-center space-x-6 text-sm text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Privacidad</a>
            <a href="#" className="hover:text-white transition-colors">Términos</a>
            <a href="#" className="hover:text-white transition-colors">Soporte</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;