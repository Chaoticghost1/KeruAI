export interface User {
  id: string;
  name: string;
  email: string;
  preferredLanguage: 'es' | 'en';
  createdAt: Date;
  qualifications: Qualification[];
  checkpoints: Checkpoint[];
}

export interface Qualification {
  id: string;
  service: string;
  level: number;
  completedAt: Date;
  skills: string[];
}

export interface Checkpoint {
  id: string;
  service: string;
  module: string;
  completedAt: Date;
  score?: number;
  timeSpent: number;
}

export interface ServiceCard {
  id: string;
  type: 'card' | 'section';
  content: {
    es: {
      title: string;
      description: string;
      cta?: string;
    };
    en: {
      title: string;
      description: string;
      cta?: string;
    };
  };
  link?: string;
  children?: ServiceCard[];
}

export type Language = 'es' | 'en';