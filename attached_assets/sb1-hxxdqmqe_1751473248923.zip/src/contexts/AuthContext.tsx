import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Qualification, Checkpoint } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, name: string) => void;
  logout: () => void;
  updateQualifications: (qualification: Qualification) => void;
  addCheckpoint: (checkpoint: Checkpoint) => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load user from localStorage
    const savedUser = localStorage.getItem('electrobit-user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = (email: string, name: string) => {
    const newUser: User = {
      id: crypto.randomUUID(),
      name,
      email,
      preferredLanguage: 'es',
      createdAt: new Date(),
      qualifications: [],
      checkpoints: []
    };
    setUser(newUser);
    localStorage.setItem('electrobit-user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('electrobit-user');
  };

  const updateQualifications = (qualification: Qualification) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      qualifications: [...user.qualifications, qualification]
    };
    setUser(updatedUser);
    localStorage.setItem('electrobit-user', JSON.stringify(updatedUser));
  };

  const addCheckpoint = (checkpoint: Checkpoint) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      checkpoints: [...user.checkpoints, checkpoint]
    };
    setUser(updatedUser);
    localStorage.setItem('electrobit-user', JSON.stringify(updatedUser));
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      updateQualifications,
      addCheckpoint,
      isLoading
    }}>
      {children}
    </AuthContext.Provider>
  );
};