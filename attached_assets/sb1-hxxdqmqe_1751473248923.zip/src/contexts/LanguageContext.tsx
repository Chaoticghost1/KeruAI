import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, options?: { [key: string]: any }) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

const translations = {
  es: {
    'hero.title': 'Electrobit.ai Suite',
    'hero.subtitle': 'Tecnología, educación y oportunidades para Honduras y el mundo',
    'hero.cta': 'Explora la suite',
    'auth.login': 'Iniciar Sesión',
    'auth.register': 'Registrarse',
    'auth.name': 'Nombre',
    'auth.email': 'Correo Electrónico',
    'auth.welcome': 'Bienvenido/a',
    'auth.logout': 'Cerrar Sesión',
    'dashboard.progress': 'Tu Progreso',
    'dashboard.checkpoints': 'Puntos de Control Completados',
    'dashboard.qualifications': 'Calificaciones',
    'footer.built': 'Construido con ❤️ desde Honduras por Kevin Guillen',
    'nav.dashboard': 'Panel'
  },
  en: {
    'hero.title': 'Electrobit.ai Suite',
    'hero.subtitle': 'Technology, education, and opportunity for Honduras and beyond',
    'hero.cta': 'Explore the suite',
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.name': 'Name',
    'auth.email': 'Email',
    'auth.welcome': 'Welcome',
    'auth.logout': 'Logout',
    'dashboard.progress': 'Your Progress',
    'dashboard.checkpoints': 'Completed Checkpoints',
    'dashboard.qualifications': 'Qualifications',
    'footer.built': 'Built with ❤️ from Honduras by Kevin Guillen',
    'nav.dashboard': 'Dashboard'
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('es');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('electrobit-language') as Language;
    if (savedLanguage && (savedLanguage === 'es' || savedLanguage === 'en')) {
      setLanguage(savedLanguage);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('electrobit-language', lang);
  };

  const t = (key: string, options?: { [key: string]: any }) => {
    let translation = translations[language][key as keyof typeof translations[typeof language]] || key;
    
    if (options) {
      Object.keys(options).forEach(optionKey => {
        translation = translation.replace(`{{${optionKey}}}`, options[optionKey]);
      });
    }
    
    return translation;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};