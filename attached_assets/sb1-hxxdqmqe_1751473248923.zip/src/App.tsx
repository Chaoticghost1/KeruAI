import React, { useState } from 'react';
import { BarChart3 } from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import ServiceCard from './components/ServiceCard';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { services } from './data/services';
import { useAuth } from './contexts/AuthContext';

const AppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<'home' | 'dashboard'>('home');
  const { user, addCheckpoint } = useAuth();

  const handleServiceClick = (serviceId: string) => {
    // Simulate using a service and adding a checkpoint
    if (user) {
      const checkpoint = {
        id: crypto.randomUUID(),
        service: serviceId,
        module: 'introduction',
        completedAt: new Date(),
        score: Math.floor(Math.random() * 30 + 70), // Random score between 70-100
        timeSpent: Math.floor(Math.random() * 1800 + 300) // Random time between 5-35 minutes
      };
      addCheckpoint(checkpoint);
    }
    
    // In a real app, this would navigate to the actual service
    alert(`Launching ${serviceId}... (Demo mode)`);
  };

  const renderServices = (serviceList: typeof services) => {
    return serviceList.map((service) => {
      if (service.type === 'section' && service.children) {
        return (
          <div key={service.id} className="col-span-full">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {service.content['es'].title}
              </h2>
              <p className="text-gray-600">
                {service.content['es'].description}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {service.children.map((child) => (
                <ServiceCard
                  key={child.id}
                  service={child}
                  onClick={() => handleServiceClick(child.id)}
                />
              ))}
            </div>
          </div>
        );
      }

      return (
        <ServiceCard
          key={service.id}
          service={service}
          onClick={() => handleServiceClick(service.id)}
        />
      );
    });
  };

  if (currentView === 'dashboard') {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="pt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <button
              onClick={() => setCurrentView('home')}
              className="mb-6 text-blue-600 hover:text-blue-700 font-medium"
            >
              ← Volver al inicio
            </button>
          </div>
        </div>
        <Dashboard />
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <Hero />

      {/* Navigation to Dashboard */}
      {user && (
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <button
              onClick={() => setCurrentView('dashboard')}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium transition-colors"
            >
              <BarChart3 className="w-5 h-5" />
              <span>Ver mi progreso</span>
            </button>
          </div>
        </div>
      )}

      {/* Services Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Herramientas y Servicios
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Descubre nuestra suite completa de herramientas diseñadas para potenciar tu educación, 
              finanzas y desarrollo profesional.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {renderServices(services)}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;